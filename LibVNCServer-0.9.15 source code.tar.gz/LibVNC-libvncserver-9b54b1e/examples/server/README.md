This directory contains simple examples showcasing certain parts of LibVNCServer's functionality.

Some more full-blown implementations are:

* [x11vnc](https://github.com/LibVNC/x11vnc) for X11
* [droidVNC-NG](https://github.com/bk138/droidVNC-NG) for Android
* [macVNC](https://github.com/LibVNC/macVNC) for macOS
